#full{shape}

import numpy as np

filled_array=np.full((2,2),7)
print(filled_array)