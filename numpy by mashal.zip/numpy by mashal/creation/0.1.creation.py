#creation form python list
#np.array([ele1,ele2,ele3])

import numpy as np
arr=np.array([1,2,3,4,5])
print(arr)