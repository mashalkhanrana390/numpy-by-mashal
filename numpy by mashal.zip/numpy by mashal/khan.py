import pyjokes

# print("printing jokes...") 
joke = pyjokes.get_joke()

# this print a radndom joke
print(joke)

"""
# so thanks
# that was my program
# """
# another line 
# yet another line 