import numpy as np

temperatures=np.array([23.3,34,5,56.7])
average=np.mean(temperatures)
print(average)