name="mashal "
rollno= 46
program = "bs ai"
is_student = True

# printing variables
print(name)
print(rollno)
print(program)
print(is_student)