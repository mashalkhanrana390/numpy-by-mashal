from docx import Document
from docx.shared import Pt

# Create a new Word Document
doc = Document()

# Title
doc.add_heading('OOP (Object Oriented Programming) Notes', 0)

# Topic 1: Class and Object
doc.add_heading('1. Class and Object', level=1)
doc.add_paragraph(
    "• Class: A blueprint or template for creating objects. It defines properties (attributes) and behaviors (methods).\n"
    "• Object: An instance of a class, representing a real-world entity."
)

# Topic 2: Private and Public
doc.add_heading('2. Private and Public', level=1)
doc.add_paragraph(
    "• Public: Members (variables or methods) that can be accessed from anywhere.\n"
    "• Private: Members that are accessible only within the class. In Python, prefix with '__' to make private."
)

# Topic 3: Encapsulation
doc.add_heading('3. Encapsulation', level=1)
doc.add_paragraph(
    "• Encapsulation is the concept of wrapping data (variables) and methods into a single unit (class).\n"
    "• It restricts direct access to some of the object's components, providing data hiding."
)

# Topic 4: Constructor
doc.add_heading('4. Constructor', level=1)
doc.add_paragraph(
    "• A constructor is a special method that is automatically called when an object is created.\n"
    "• In Python, the constructor is defined using __init__() method.\n"
    "Example:\n"
    "  class Student:\n"
    "      def __init__(self, name, roll):\n"
    "          self.name = name\n"
    "          self.roll = roll"
)

# Topic 5: Inheritance
doc.add_heading('5. Inheritance', level=1)
doc.add_paragraph(
    "• Inheritance allows a class (child/subclass) to acquire the properties and methods of another class (parent/superclass).\n"
    "• Promotes code reusability."
)

# Topic 6: Types of Inheritance
doc.add_heading('6. Types of Inheritance', level=1)

doc.add_paragraph(
    "• Single Inheritance: A child class inherits from a single parent class.\n"
    "  Example:\n"
    "    class Parent:\n"
    "        pass\n"
    "    class Child(Parent):\n"
    "        pass\n\n"
    "• Multiple Inheritance: A child class inherits from more than one parent class.\n"
    "  Example:\n"
    "    class Parent1:\n"
    "        pass\n"
    "    class Parent2:\n"
    "        pass\n"
    "    class Child(Parent1, Parent2):\n"
    "        pass\n\n"
    "• Multilevel Inheritance: A class inherits from a child class, forming a chain.\n"
    "  Example:\n"
    "    class Grandparent:\n"
    "        pass\n"
    "    class Parent(Grandparent):\n"
    "        pass\n"
    "    class Child(Parent):\n"
    "        pass"
)

# Save the Word document
file_name = 'OOP_Notes.docx'
doc.save(file_name)

print(f"Word document '{file_name}' created successfully!")