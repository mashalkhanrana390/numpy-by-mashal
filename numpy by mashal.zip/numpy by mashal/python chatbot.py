import sys
import json
import urllib.request
import urllib.error
from datetime import datetime

# ======================================================
#   PASTE YOUR REAL API KEY BELOW (replace the dots)
#   Get it from: https://console.anthropic.com/settings/keys
# ======================================================

API_KEY = "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"

# ======================================================
#   DO NOT EDIT BELOW THIS LINE
# ======================================================

API_URL       = "https://api.anthropic.com/v1/messages"
MODEL         = "claude-sonnet-4-20250514"
MAX_TOKENS    = 1024
SYSTEM_PROMPT = "You are a helpful, friendly, and concise assistant."

USE_COLOR = sys.stdout.isatty()

def c(code, text):
    return f"\033[{code}m{text}\033[0m" if USE_COLOR else text

CYAN   = lambda t: c("96", t)
GREEN  = lambda t: c("92", t)
YELLOW = lambda t: c("93", t)
DIM    = lambda t: c("2",  t)
BOLD   = lambda t: c("1",  t)
RED    = lambda t: c("91", t)


def chat(history):
    payload = json.dumps({
        "model":      MODEL,
        "max_tokens": MAX_TOKENS,
        "system":     SYSTEM_PROMPT,
        "messages":   history,
    }).encode()

    req = urllib.request.Request(
        API_URL,
        data=payload,
        headers={
            "Content-Type":      "application/json",
            "x-api-key":         API_KEY,
            "anthropic-version": "2023-06-01",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read())
            return data["content"][0]["text"]
    except urllib.error.HTTPError as e:
        body = e.read().decode(errors="replace")
        try:
            msg = json.loads(body).get("error", {}).get("message", body)
        except json.JSONDecodeError:
            msg = body
        raise RuntimeError(f"API error {e.code}: {msg}")


def main():
    print(CYAN("""
  ╔═══════════════════════════════════════╗
  ║         Claude  Python  Chatbot       ║
  ║   quit = exit  |  /clear = reset      ║
  ╚═══════════════════════════════════════╝
"""))

    # Check key is set correctly
    if (not API_KEY
            or "REPLACE" in API_KEY
            or "PASTE"   in API_KEY
            or "xxx"     in API_KEY.lower()
            or len(API_KEY) < 40):
        print(RED("  ✗  API key is missing or invalid!\n"))
        print(YELLOW("  Open chatbot.py and edit line 8:"))
        print()
        print(DIM('  Change:  API_KEY = "sk-ant-api03-REPLACE-THIS-WITH-YOUR-REAL-KEY"'))
        print(DIM('  To:      API_KEY = "sk-ant-api03-your-actual-key-from-anthropic"'))
        print()
        print(YELLOW("  Get your key → https://console.anthropic.com/settings/keys"))
        print()
        sys.exit(1)

    print(DIM(f"  Key   : {API_KEY[:22]}..."))
    print(DIM(f"  Model : {MODEL}"))
    print(DIM(f"  Type a message and press Enter.\n"))

    history = []

    while True:
        try:
            user_input = input(BOLD(GREEN("You")) + DIM(" › ")).strip()
        except (EOFError, KeyboardInterrupt):
            print(f"\n{DIM('Goodbye!')}")
            break

        if not user_input:
            continue

        if user_input.lower() in {"quit", "exit", "bye"}:
            print(DIM("Goodbye!"))
            break

        if user_input.lower() in {"/clear", "/reset"}:
            history.clear()
            print(YELLOW("  ↺  Conversation cleared.\n"))
            continue

        if user_input.lower() == "/history":
            if not history:
                print(DIM("  (no history yet)\n"))
            else:
                for i, m in enumerate(history, 1):
                    role    = CYAN("Claude") if m["role"] == "assistant" else GREEN("You")
                    snippet = m["content"][:80] + ("..." if len(m["content"]) > 80 else "")
                    print(f"  {DIM(str(i)+'.')} {role}: {snippet}")
                print()
            continue

        if user_input.lower() in {"/help", "/?"}:
            print(YELLOW(
                "\n  Commands:\n"
                "    /clear   – erase conversation history\n"
                "    /history – show recent messages\n"
                "    /help    – show this message\n"
                "    quit     – exit\n"
            ))
            continue

        history.append({"role": "user", "content": user_input})
        print(DIM("  thinking..."), end="\r", flush=True)

        try:
            reply = chat(history)
        except RuntimeError as err:
            print(f"  {RED('Error:')} {err}\n")
            history.pop()
            continue

        history.append({"role": "assistant", "content": reply})

        time_str = DIM(datetime.now().strftime("%H:%M"))
        print(f"\r{BOLD(CYAN('Claude'))} {DIM('›')} {time_str}")
        for line in reply.splitlines():
            print(f"  {line}")
        print()


if __name__ == "__main__":
    main()