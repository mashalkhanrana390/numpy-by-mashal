a=23

aaa=436

mashal =2829


print(mashal)