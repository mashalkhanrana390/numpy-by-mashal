import numpy as np

arr = np.array([10, 20, 30, 40, 50, 60])

reshaped_Arr = arr.reshape(3,2)

print(reshaped_Arr)