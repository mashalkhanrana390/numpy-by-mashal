"""
array[index]#1 array
array[row,column]#2d
"""


import numpy as np

arr = np.array([12, 34, 56])

print(arr[0])
print(arr[1])
print(arr[2])