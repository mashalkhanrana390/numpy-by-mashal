import numpy as np 

arr=np.array([12,34,56,78])

print(arr[0:3])
print(arr[:4])
print(arr[::2])
print(arr[::-1])