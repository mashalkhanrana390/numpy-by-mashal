#multi-dimensional array
import numpy as np

matrix=np.array([[2,3,4],
                 [5,6,7],
                 [4,7,0]])
print(matrix)
