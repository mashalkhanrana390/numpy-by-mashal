import os

path = "/"

if os.path.exists(path):
    print("Contents of directory:", path)
    for item in os.listdir(path):
        print(item)
else:

    print the contents of the directory
    print("contents")