import numpy as np 

arr=np.array([12,34,90,78])

print(np.sum(arr))
print(np.mean(arr))
print(np.min(arr))
print(np.max(arr))