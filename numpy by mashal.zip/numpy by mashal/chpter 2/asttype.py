# import numpy as np

# arr = np.array([1.2, 3.4, 3.5])

# int_arr = arr.astype(int)

# print(int_arr.dtype)
# print(int_arr)
import numpy as np

arr = np.array([1, 2, 3])

float_arr = arr.astype(float)

print(float_arr.dtype)
print(float_arr)