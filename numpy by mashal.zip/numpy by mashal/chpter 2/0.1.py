#numpy array properites
#cheak size and shape type
