temperatures=[23.,45.56,57.8]

total=0
for temp in temperatures:
    total += temp
    
average=total/len(temperatures)
print(average)