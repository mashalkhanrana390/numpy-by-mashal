#  arithmetic operators

a=18

b=2

c=a+b
print(c)

# assignemt operatorss
a=10-4# assgin 10-3 in a
print(a)
b=6 
print(b)
# increment and decrement operators
b*= 3 # increment b by 3 (b=b+3)



# compasrison operators
d=5==5
print(d)



# logical operators
e=True and False
print(e)
print(True 0r False)
print(not True)
print(not False)
print(not(True and False))
print(not(True or False))
