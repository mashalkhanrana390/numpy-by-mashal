import numpy as np

arr=np.array([10,20,30])
print(arr)
new_arr=np.insert(arr,1,100,)
print(new_arr)