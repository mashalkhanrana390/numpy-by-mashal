a =(1,33,5666,False,"mashal","hamza")
print(a)
print(type(a))