name= input("Enter your name: ")

print(f" hello mashal ,{name}")