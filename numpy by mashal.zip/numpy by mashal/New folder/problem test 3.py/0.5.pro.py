friends = ["Alice", "Bob", "Charlie"]

print(friends[0])  # Output: Alice