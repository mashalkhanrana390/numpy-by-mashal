l=[2,3,4,8]

print(sum(l))



a = (7,0,8,0,9,0,0,0,0)

n= a.count(0)
print(n)