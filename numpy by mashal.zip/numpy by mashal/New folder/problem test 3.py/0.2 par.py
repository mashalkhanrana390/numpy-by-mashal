marks = []

f1 = int(input("Enter the marks here: "))
marks.append(f1)

f2 = int(input("Enter the marks here: "))
marks.append(f2)

f3 = int(input("Enter the marks here: "))
marks.append(f3)

f4 = int(input("Enter the marks here: "))
marks.append(f4)

f5 = int(input("Enter the marks here: "))
marks.append(f5)

f6 = int(input("Enter the marks here: "))
marks.append(f6)

marks.sort()
print(marks)




a =(23,34,"mashal")

a[2]="masahl"