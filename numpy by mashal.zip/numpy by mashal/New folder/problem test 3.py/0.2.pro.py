letter = ''' Dear <|NAME|>,
                  you are selected!
                  <|Date|>'''

print(letter.replace("<|NAME|>", "Mashal").replace("<|Date|>", "20/06/2024"))