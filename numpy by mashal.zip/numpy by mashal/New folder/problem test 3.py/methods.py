a=(1,244,3,3,4)
print(a)
print(type(a))


no=a.count(244)
print(no)


a=(1.3,4,5)
b=(2,3,6,7)

print(a+b)
