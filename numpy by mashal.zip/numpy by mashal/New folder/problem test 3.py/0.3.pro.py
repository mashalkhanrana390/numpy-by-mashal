name ="mashal is good  boy"

print(name.replace("  ", " "))
print(name)