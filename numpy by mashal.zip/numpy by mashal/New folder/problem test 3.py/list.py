friends =["Alice","bob","apple","garpes"]
print(friends)

friends.append("mashal")

print(friends)
l1=[1,2,23,3,3]

l1.remove(23)
print(l1)