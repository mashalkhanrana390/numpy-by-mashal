a =int(input("Enter number 1:"))
b =int(input("Enter number 2: "))


p
print(" the square of the number is", a**2)
print(" the square of the number is", a*a)
# print(" the square of the number is", a^b)
