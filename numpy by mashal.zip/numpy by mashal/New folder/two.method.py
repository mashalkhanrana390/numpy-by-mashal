

print("mashal\nkhan")
print("mashal\trana")
print("gamza\bkhan")
print("ai\ is  my field")
