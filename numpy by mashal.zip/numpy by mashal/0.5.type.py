a = "32.1"
# b= a but type(a) is str
b = float(a)  # Convert string to float
t = type(b)  # class 'float'

print(t)