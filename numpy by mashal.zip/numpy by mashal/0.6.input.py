a = int (input("Enter a number 1 "))

b= int(input("Enter a number 2"))1


print("number a is:",a)
print("number a is:",b)

print("sum is ", a+b)
