#include<iostream>
using namespace std;

int main(){
    cout<<"mashal"<<endl;

    return 0;
}